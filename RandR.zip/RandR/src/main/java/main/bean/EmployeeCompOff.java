package main.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "employeecompoff")
public class EmployeeCompOff {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "COMPOFF_ID")
    private Long compOffId;
    @Column(name = "EMP_ID ")
    private Integer empId;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "COMPOFF_STATUS")
    private String compOffStatus;
    @Column(name = "ABSENCE_TYPE")
    private String absenseType;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Kolkata")
    @Temporal(TemporalType.DATE)
    @Column(name = "START_DATE ")
    private Date startDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Kolkata")
    @Temporal(TemporalType.DATE)
    @Column(name = "END_DATE ")
    private Date endDate;
    @Column(name = "LOB")
    private String lob;
    @Column(name = "PROJECT_ID ")
    private int projectId;
    @Column(name = "PROJECT_NAME")
    private String projectName;
    @Column(name = "LOCATION")
    private String location;
    @Column(name = "DELIVERY_MANAGER")
    private String deliveryManager;
    @Column(name = "PART_OF_WEEKEND_INTERVIEW")
    private String partOfWeeekendInterview;
    @Column(name = "QUARTERLY_VOUCHER_STATUS")
    private String quarterlyVoucherStatus;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Kolkata")
    @Temporal(TemporalType.DATE)
    @Column(name = "DATE_OF_INTERVIEW_WORK")
    private Date dateOfInterviewWork;
    @Column(name = "REASON")
    private String reason;
    @Column(name = "COMMENTS")
    private String comments;
    @Column(name="EXCEPTION")
    private String exception;

    public EmployeeCompOff() {
    }

    public Long getCompOffId() {
        return compOffId;
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getCompOffStatus() {
        return compOffStatus;
    }

    public void setCompOffStatus(String compOffStatus) {
        this.compOffStatus = compOffStatus;
    }

    public String getAbsenseType() {
        return absenseType;
    }

    public void setAbsenseType(String absenseType) {
        this.absenseType = absenseType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDeliveryManager() {
        return deliveryManager;
    }

    public void setDeliveryManager(String deliveryManager) {
        deliveryManager = deliveryManager;
    }

    public String getPartOfWeeekendInterview() {
        return partOfWeeekendInterview;
    }

    public void setPartOfWeeekendInterview(String partOfWeeekendInterview) {
        this.partOfWeeekendInterview = partOfWeeekendInterview;
    }

    public String getQuarterlyVoucherStatus() {
        return quarterlyVoucherStatus;
    }

    public void setQuarterlyVoucherStatus(String quarterlyVoucherStatus) {
        this.quarterlyVoucherStatus = quarterlyVoucherStatus;
    }

    public Date getDateOfInterviewWork() {
        return dateOfInterviewWork;
    }

    public void setDateOfInterviewWork(Date dateOfInterviewWork) {
        this.dateOfInterviewWork = dateOfInterviewWork;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getException() {
        return exception;
    }

    public void setException(String exception) {
        this.exception = exception;
    }
}