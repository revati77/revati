package main.bean;

import org.springframework.stereotype.Component;

@Component
public class CompOffDetails {

    private Integer empId;
    private String empName;
    private String status;
    private String absenseType;
    private String startDate;
    private String endDate;
    private String partOfInterview;
    private String reason;
    private String lob;
    private int projectId;
    private String projectName;
    private String location;
    private String DeliveryManager;

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAbsenseType() {
        return absenseType;
    }

    public void setAbsenseType(String absenseType) {
        this.absenseType = absenseType;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getPartOfInterview() {
        return partOfInterview;
    }

    public void setPartOfInterview(String partOfInterview) {
        this.partOfInterview = partOfInterview;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDeliveryManager() {
        return DeliveryManager;
    }

    public void setDeliveryManager(String deliveryManager) {
        DeliveryManager = deliveryManager;
    }
}
