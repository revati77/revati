package main.bean;

import javax.persistence.*;

@Entity
@Table(name = "nominationcriteria")
public class NominationCriteria {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CRITERIA_ID")
    private Integer criteriaId;
 /*   @OneToMany(fetch = FetchType.LAZY,mappedBy = "nominationcriteria")
    private List<NominationRemark> nominationRemarks*/;

    @Column(name = "REWARD_TYPE")
    private String rewardType;
    @Column(name = "CRITERIA")
    private String criteria;

    //Getters and Setters and Constructor

    public NominationCriteria() {
    }

 /*   public List<NominationRemark> getNominationRemarks() {
        return nominationRemarks;
    }

    public void setNominationRemarks(List<NominationRemark> nominationRemarks) {
        this.nominationRemarks = nominationRemarks;
    }*/

    public Integer getCriteriaId() {
        return criteriaId;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public String getCriteria() {
        return criteria;
    }

    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }
}
