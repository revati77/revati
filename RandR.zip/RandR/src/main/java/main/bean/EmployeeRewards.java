package main.bean;

import javax.persistence.*;

@Entity
@Table(name = "employeerewards")
public class EmployeeRewards {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "EMP_ID")
    private Integer empId;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "REWARD_TYPE")
    private String rewardType;
    @Column(name = "SKILL")
    private String skill;
    @Column(name = "LOCATION")
    private String location;
    @Column(name = "NO_OF_INTERVIEWS")
    private Integer noOfInterviews;
    @Column(name = "NO_OF_POINTS")
    private Integer noOfPoints;
    @Column(name = "DATE_OF")
    private String dateOf;
    @Column(name = "CREATED_BY")
    private Integer createdby;
    @Column(name = "MODIFIED_BY")
    private Integer modifiedBy;
    @Column(name = "MANAGER_ID")
    private Integer managerId;
    @Column(name = "ADVANCE_COMPOFF")
    private String advanceCompoff;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "ELIGIBLE_FOR_COMPOFF")
    private String eligibleForCompoff;

    public EmployeeRewards() {
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Integer getNoOfInterviews() {
        return noOfInterviews;
    }

    public void setNoOfInterviews(Integer noOfInterviews) {
        this.noOfInterviews = noOfInterviews;
    }

    public Integer getNoOfPoints() {
        return noOfPoints;
    }

    public void setNoOfPoints(Integer noOfPoints) {
        this.noOfPoints = noOfPoints;
    }

    public String getDateOf() {
        return dateOf;
    }

    public void setDateOf(String dateOf) {
        this.dateOf = dateOf;
    }

    public Integer getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Integer createdby) {
        this.createdby = createdby;
    }

    public Integer getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public String getAdvanceCompoff() {
        return advanceCompoff;
    }

    public void setAdvanceCompoff(String advanceCompoff) {
        this.advanceCompoff = advanceCompoff;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEligibleForCompoff() {
        return eligibleForCompoff;
    }

    public void setEligibleForCompoff(String eligibleForCompoff) {
        this.eligibleForCompoff = eligibleForCompoff;
    }
}