package main.bean;

import org.springframework.stereotype.Component;

@Component
public class EmployeeCompoff {
    private int employee_id;
    private String reward_type;
    private String eligibility_response;

    public String getDate_of() {
        return Date_of;
    }

    public void setDate_of(String date_of) {
        Date_of = date_of;
    }

    private String Date_of;


    public String getEligibility_response() {
        return eligibility_response;
    }

    public void setEligibility_response(String eligibility_response) {
        this.eligibility_response = eligibility_response;
    }



    public int getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(int employee_id) {
        this.employee_id = (int) employee_id;
    }

    public String getReward_type() {
        return reward_type;
    }

    public void setReward_type(String reward_type) {
        this.reward_type = reward_type;
    }





}
