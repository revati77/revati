package main.repository;


import main.bean.EmployeeRewards;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface EmployeeRewardsRepository extends JpaRepository<EmployeeRewards, Long> {
    @Query(value = "select * from employeerewards e where e.EMP_ID=?1", nativeQuery = true)
    List<EmployeeRewards> findByEmpId(Integer EMP_ID);

    @Query(value = "select * from employeerewards e where e.MANAGER_ID=?1", nativeQuery = true)
    List<EmployeeRewards> findByManagerId(Integer MANAGER_ID);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeRewards WHERE id = ?1", nativeQuery = true)
    void deleteById(Long id);
}
