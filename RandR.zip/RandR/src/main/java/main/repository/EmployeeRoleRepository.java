package main.repository;

import main.bean.EmployeeRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface EmployeeRoleRepository extends JpaRepository<EmployeeRole, Integer> {

    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeRole WHERE EMP_ID = ?1", nativeQuery = true)
    void deleteById(Integer empId);
}
