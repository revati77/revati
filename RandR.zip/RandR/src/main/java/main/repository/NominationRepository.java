package main.repository;

import main.bean.Nomination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface NominationRepository extends JpaRepository<Nomination, Long> {

    @Modifying
    @Transactional
    @Query(value="DELETE FROM Nomination WHERE id = ?1")
    void deleteInNomination(Long id);

    @Query(value ="select n from nomination n where n.nomineeId=?1", nativeQuery = true)
    Optional<Nomination> findByNomineeid(Integer nominee_id);

}
