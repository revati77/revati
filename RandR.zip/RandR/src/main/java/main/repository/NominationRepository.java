package main.repository;

import main.bean.Nomination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface NominationRepository extends JpaRepository<Nomination, Integer> {
    @Query(value ="select * from nomination n where n.NOMINEE_ID=?1", nativeQuery = true)
    List<Nomination> findByNomineeId(Integer NOMINEE_ID);

    @Query(value ="select * from nomination n where n.PMO_ID=?1", nativeQuery = true)
    List<Nomination> findByPmoId(Integer PMO_ID);

    @Query(value ="select * from nomination n where n.MANAGER_ID=?1", nativeQuery = true)
    List<Nomination> findByManagerId(Integer MANAGER_ID);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM Nomination WHERE id = ?1")
    void deleteInNomination(Long id);

    @Modifying
    @Transactional
    @Query(value="UPDATE Nomination e SET e.points=?2,e.nominationStatus=?3 WHERE e.id = ?1")
    void updateStatus(Long id,Integer points, String nominationStatus);

    @Query(value ="SELECT e FROM Nomination e WHERE e.nominationStatus=:nominationStatus AND e.nominationDate BETWEEN :startDate AND :endDate")
    List<Nomination> getQuarterList(@Param("nominationStatus")String nominationStatus, @Param("startDate") Date date1, @Param("endDate") Date date2);

    @Modifying
    @Transactional
    @Query(value="UPDATE Nomination e SET e.nominationStatus=?4 WHERE e.nomineeId = ?1 AND e.term=?2 AND e.rewardType=?3")
    void updateVoucherStatus(Integer nomineeId, String term, String rewardType, String nominationStatus);

    @Query(value ="SELECT e FROM Nomination e WHERE e.nominationStatus=:nominationStatus AND e.nominationDate BETWEEN :startDate AND :endDate")
    List<Nomination> downloadNominaionDetails(@Param("nominationStatus")String nominationStatus, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
}
