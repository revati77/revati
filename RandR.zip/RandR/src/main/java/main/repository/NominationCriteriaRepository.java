package main.repository;

import main.bean.NominationCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface NominationCriteriaRepository extends JpaRepository<NominationCriteria, Integer> {
    @Query("select r from NominationCriteria r where r.rewardType=?1")
    List<NominationCriteria> findByRewardType(String reward_type);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM NominationCriteria WHERE criteriaId = ?1")
    void deleteById(Integer criteriaId);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM NominationCriteria WHERE rewardType = ?1")
    void deleteByRewardType(String rewardType);
}
