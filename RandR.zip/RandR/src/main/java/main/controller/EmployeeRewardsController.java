package main.controller;


import main.bean.EmployeeRewards;

import main.service.EmployeeRewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employeeRewards")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeRewardsController {

    @Autowired
    private EmployeeRewardsService employeeRewardsService;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeRewards createEmployee(@Valid @RequestBody EmployeeRewards employeeRewards) {
        return employeeRewardsService.save( employeeRewards );
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeRewards> getAll() {
        return employeeRewardsService.findAll();
    }

    /*  to retrieve by employee id*/
    @GetMapping("/getByEmployeeId/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeRewards> getId(@PathVariable("EMP_ID") final Integer EMP_ID) {
        return employeeRewardsService.getId( EMP_ID );
    }

    // to retrieve by employee id
    @GetMapping("/getByManagerId/{MANAGER_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeRewards> getByManagerId(@PathVariable("MANAGER_ID") final Integer MANAGER_ID) {
        return employeeRewardsService.getByManagerId( MANAGER_ID );
    }

    //  to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeRewards update(@RequestBody EmployeeRewards employeeRewards) {
        return employeeRewardsService.update( employeeRewards );
    }

    //To delete
    @DeleteMapping("/deleteByid/{ID}")
    public void delete(@PathVariable("ID") final Long id) {
        employeeRewardsService.delete( id );
    }
}
