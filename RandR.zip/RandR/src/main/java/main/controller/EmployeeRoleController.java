package main.controller;

import main.bean.EmployeeRole;
import main.service.EmployeeRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employeeRole")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeRoleController {

    @Autowired
    private EmployeeRoleService employeeRoleService;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeRole createEmployee(@Valid @RequestBody EmployeeRole employeerole) {
        return employeeRoleService.save( employeerole );
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeRole> getAll() {
        return employeeRoleService.findAll();
    }

    //  to retrieve by id
    @GetMapping("/getByid/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<EmployeeRole> getId(@PathVariable("EMP_ID") final Integer EMP_ID) {
        return employeeRoleService.findById( EMP_ID );
    }

    //  to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeRole update(@RequestBody EmployeeRole employeeRole) {
        return employeeRoleService.update( employeeRole );
    }

    // to validate EmployeeId and Password
    @GetMapping("/role/{EMP_ID}/{PASSWORD}")
    public ResponseEntity getRole(@PathVariable("EMP_ID") Integer EMP_ID, @PathVariable("PASSWORD") String PASSWORD) {

        String role = employeeRoleService.getRole( EMP_ID, PASSWORD );

        if (role != null) {
            return new ResponseEntity( role, HttpStatus.OK );
        } else {
            return new ResponseEntity<>( "InvalidLogin", HttpStatus.INTERNAL_SERVER_ERROR );
        }
    }

    //To delete
    @DeleteMapping("/deleteByid/{EMP_ID}")
    public void delete(@PathVariable("EMP_ID") final Integer empId) {
        employeeRoleService.delete(empId);
    }
}
