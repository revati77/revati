package main.controller;

import main.bean.PointsValue;
import main.service.PointsValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/points")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class PointsValueController {
    @Autowired
    private PointsValueService pointsValueService;

    //  to save
    @PostMapping("/save")
    public PointsValue createEmployee(@Valid @RequestBody PointsValue pointsValue) {
        return pointsValueService.save( pointsValue );
    }

    // to retrieve all
    @GetMapping("/all")
    public List<PointsValue> getAll() {
        return pointsValueService.getAll();
    }

    //  to retrieve by id
    @GetMapping("/getByid/{REWARD_TYPE}")
    public Optional<PointsValue> getId(@PathVariable("REWARD_TYPE") final String REWARD_TYPE) {
        return pointsValueService.getById( REWARD_TYPE );
    }

    // to update all
    @PutMapping("/update")
    public PointsValue update(@RequestBody PointsValue pointsValue) {
        return pointsValueService.update( pointsValue );
    }

    //to delete
    @DeleteMapping("/deleteByid/{POINTS_ID}")
    public void delete(@PathVariable("POINTS_ID") final Integer pointsId) {
        pointsValueService.delete( pointsId );
    }
}
