package main.service;

import main.bean.CompOffDetails;
import main.bean.EmployeeCompoff;
import main.bean.EmployeeRewards;
import main.repository.EmployeeRewardsRepository;
//import main.util.UpdateRewardStatusService;
import main.util.CompOffExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRewardsService {

    @Autowired
    private EmployeeRewardsRepository employeeRewardsRepository;

    @Autowired
    private CompOffExcelReader compOffExcelReader;

    @Autowired
    CompOffDetails compOffDetails;

    //   To save
    public EmployeeRewards save(EmployeeRewards employeeRewards) {
        return employeeRewardsRepository.save( employeeRewards );
    }

    // retrieve all employeerole details
    public List<EmployeeRewards> findAll() {
        return employeeRewardsRepository.findAll();
    }

    //    Get by employee id
    public List<EmployeeRewards> getId(Integer EMP_ID) {
        return employeeRewardsRepository.findByEmpId(EMP_ID);
    }

    //    Get by manager id
    public List<EmployeeRewards> getByManagerId(Integer EMP_ID) {
        return employeeRewardsRepository.findByManagerId(EMP_ID);
    }

    //    to update
    public EmployeeRewards update(EmployeeRewards employeeRewards) {
        return employeeRewardsRepository.save(employeeRewards);
    }

    //To delete all
    public void delete(Long id)
    {
        employeeRewardsRepository.deleteById(id);
    }

    //To Update Status
    public void statusUpdate(Long id, String status) {
        long id1=id;
        String status1=status;
        if(status1.equals("Approved") || status1.equals("Rejected"))
        {
            employeeRewardsRepository.updateStatus(id1,status1);
        }
     }

    public Optional<EmployeeRewards> getById(Long id) {
        return employeeRewardsRepository.findById(id);
    }

    // Fetch CompOff Details

    public List<CompOffDetails> readCompOffExcel(MultipartFile file) throws IOException, ParseException {
        List<CompOffDetails> compOffDetails = compOffExcelReader.readCompOff(file);
        return compOffDetails;
    }

}
