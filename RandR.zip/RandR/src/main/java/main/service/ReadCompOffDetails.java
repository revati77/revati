package main.service;

import main.bean.EmployeeCompoff;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class ReadCompOffDetails
{

    @Autowired
    FetchCompOffEligibility fetchCompOffEligibility = new FetchCompOffEligibility();
    //Create the input stream from the xlsx/xls file
    public List<EmployeeCompoff> readExcelData(String SampleSheet)
    {
//        System.out.println("Its in");
        List<EmployeeCompoff> employeeCompoffs = new ArrayList<EmployeeCompoff>();
        try
        {
            FileInputStream fis = new FileInputStream(SampleSheet);

            //Create workbook instance for xlsx/xls file input stream
            Workbook workbook = null;
            if (SampleSheet.toLowerCase().endsWith("xlsx"))
            {
                workbook = new XSSFWorkbook(fis);
            }
            else if (SampleSheet.toLowerCase().endsWith("xls"))
            {
                workbook=new HSSFWorkbook(fis);
            }

            //get the number of sheets in the xlsx file
            int numberOfSheets = workbook.getNumberOfSheets();

            for (int i=0; i<numberOfSheets; i++)
            {
                Sheet sheet = workbook.getSheetAt(i);
                Iterator<Row> rowIterator = sheet.iterator();
                while (rowIterator.hasNext())
                {
                    EmployeeCompoff employeeCompoff = new EmployeeCompoff() ;


                    Row row = rowIterator.next();

                    employeeCompoff.setEmployee_id((int) row.getCell(0).getNumericCellValue());
                    employeeCompoff.setReward_type(row.getCell(1).getStringCellValue());

                    String date_of =  row.getCell(2).getStringCellValue();

                    DateTimeFormatter simpleDateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    DateTimeFormatter simpleDateFormat1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");


                    employeeCompoff.setDate_of(LocalDate.parse(date_of,simpleDateFormat).format(simpleDateFormat1));
//                    System.out.println(employeeCompoff.getDate_of());
                    employeeCompoff.setEligibility_response(fetchCompOffEligibility.fetchCompOffEligibility(employeeCompoff));
                    employeeCompoffs.add(employeeCompoff);

                }
            }
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
//        catch (ParseException e) {
//            e.printStackTrace();
//        }
//        System.out.println(employeeCompoffs);
        return employeeCompoffs;
    }
}
