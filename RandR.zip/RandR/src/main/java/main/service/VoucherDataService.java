package main.service;

import main.bean.Nomination;
import main.bean.VoucherData;
import main.repository.VoucherDataRepository;
import main.util.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.List;

@Service
public class VoucherDataService {

    @Autowired
    private VoucherDataRepository voucherDataRepository;

    @Autowired
    private QuarterlyNomination quarterlyNomination;

    @Autowired
    private QuarterlyReward quarterlyReward;

    @Autowired
    private ProcessQuarterlyNomination processQuarterlyNomination;

    @Autowired
    private ProcessQuarterlyReward processQuarterlyReward;

    @Autowired
    private VoucherDataDownload voucherDataDownload;

    // to get all
    public List<VoucherData> getAll() {
        return voucherDataRepository.findAll();
    }

    public List<VoucherData> getQuarterlyData(String quarter, Integer year){
        return voucherDataRepository.getQuarterlyData(quarter, year);
    }

    public List<VoucherData> getQuarterlyNomination(String quarter, Integer year){
        return quarterlyNomination.quarterlyNomination(quarter, year);
    }

    public List<VoucherData> getQuarterlyReward(String quarter, Integer year){
        return quarterlyReward.quarterlyReward(quarter, year);
    }

    public List<VoucherData> processQuarterlyNomination(List<VoucherData> voucherData, String quarter, Integer year) throws ParseException {
        return processQuarterlyNomination.processQuarterlyNomination(voucherData, quarter, year);
    }

    public List<VoucherData> processQuarterlyReward(List<VoucherData> voucherData, String quarter, Integer year) throws ParseException {
        return processQuarterlyReward.processQuarterlyReward(voucherData,quarter,year);
    }

    public XSSFWorkbook downloadQuarterlyVoucher(String quarter, Integer year){
        return voucherDataDownload.voucherDataDownload(quarter, year);
    }

}
