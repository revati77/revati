package main.service;

import main.bean.EmployeeCompOff;
import main.repository.EmployeeCompOffRepository;
import main.reports.CompOffExceptionDownload;
import main.util.ConsolidatedCompOffExcelReader;
import main.util.UpdateEmployeeCompOff;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeCompOffService {

    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    @Autowired
    private ConsolidatedCompOffExcelReader consolidatedCompOffExcelReader;

    @Autowired
    private UpdateEmployeeCompOff updateEmployeeCompOff;
    @Autowired
    private CompOffExceptionDownload compOffExceptionDownload;

    // Fetch CompOff Details
    public List<EmployeeCompOff> readCompOffExcel(String month, Integer year, MultipartFile compOffFile, MultipartFile employeeProjectInfo) throws IOException, ParseException {
        List<EmployeeCompOff> employeeCompOffs = consolidatedCompOffExcelReader.readExcelCompOff( month, year, compOffFile, employeeProjectInfo );
        return employeeCompOffs;
    }

    //To save
    public EmployeeCompOff save(EmployeeCompOff employeeCompOff) {
        return employeeCompOffRepository.save( employeeCompOff );
    }

    //To retreive all
    public List<EmployeeCompOff> getAll() {
        return employeeCompOffRepository.findAll();
    }

    //To update
    public EmployeeCompOff update(EmployeeCompOff employeeCompOff) {
        return employeeCompOffRepository.save( employeeCompOff );
    }

    public String updateCompOffList(List<EmployeeCompOff> employeeCompOffList) {
        return updateEmployeeCompOff.updateEmployeeCompOff( employeeCompOffList );
    }

    //To delete using empId
    public void deleteByEmpId(Integer empId) {
        employeeCompOffRepository.deleteByEmpId( empId );
    }

    //To delete using Id
    public void deleteById(Long compOffId) {
        employeeCompOffRepository.deleteById( compOffId );
    }


    public XSSFWorkbook downloadCompoffException(String month, Integer year) {
        return compOffExceptionDownload.compOffExceptionDownload( month, year );
    }
}



