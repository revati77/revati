package main.service;

import main.bean.EmployeeCompOff;
import main.repository.EmployeeCompOffRepository;
import main.util.ConsolidatedCompOffExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Service
public class EmployeeCompOffService {

    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    @Autowired
    private ConsolidatedCompOffExcelReader consolidatedCompOffExcelReader;

    // Fetch CompOff Details
    public List<EmployeeCompOff> readCompOffExcel(MultipartFile compOffFile, MultipartFile employeeProjectInfo) throws IOException, ParseException {
        List<EmployeeCompOff> employeeCompOffs = consolidatedCompOffExcelReader.readExcelCompOff(  compOffFile, employeeProjectInfo );
        return employeeCompOffs;
    }

    //To save
    public EmployeeCompOff save(EmployeeCompOff employeeCompOff) {
        return employeeCompOffRepository.save( employeeCompOff );
    }

    //To retreive all
    public List<EmployeeCompOff> getAll()
    {
        return employeeCompOffRepository.findAll();
    }

    //To update
    public EmployeeCompOff update(EmployeeCompOff employeeCompOff) {
        return employeeCompOffRepository.save( employeeCompOff );
    }

    //To delete using empId
    public void deleteByEmpId(Integer empId)

    {
        employeeCompOffRepository.deleteByEmpId(empId);
    }

    //To delete using Id
    public void deleteById(Long compOffId)
    {
        employeeCompOffRepository.deleteById(compOffId);
    }

}


