package main.service;

import main.bean.EmployeeRewards;
import main.util.WeekendExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Component
public class ExcelService {

    @Autowired
    private WeekendExcelReader weekendExcelReader;

    public List<EmployeeRewards> readExcel(MultipartFile file, Integer empId) throws IOException, ParseException {
        List<EmployeeRewards> employeeEntities = weekendExcelReader.read(file, empId);
        return employeeEntities;
    }

}
