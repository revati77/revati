package main.reports;

import main.bean.Nomination;
import main.repository.NominationRepository;
import main.util.CompOffDate;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class NominationDetailsDownload {

    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private CompOffDate compOffDate;

    //to retrieve nomination for that quarter who are approved
    public XSSFWorkbook downloadNominaionDetails(String quarter, Integer year,List<String> statusList) {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet( "NominationData" );
        XSSFRow row = null;
        row = sheet.createRow( 0 );

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor( IndexedColors.AQUA.getIndex() );
        Cell cell = row.createCell( 0 );
        cell.setCellValue( "Nominee Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 1 );
        cell.setCellValue( "Nominee Id" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 2 );
        cell.setCellValue( "Manager Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 3 );
        cell.setCellValue( "Manager Id" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 4 );
        cell.setCellValue( "Nominator Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 5 );
        cell.setCellValue( "Nominator Id" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 6 );
        cell.setCellValue( "Lob" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 7 );
        cell.setCellValue( "Term" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 8 );
        cell.setCellValue( "Reward Type" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 9 );
        cell.setCellValue( "Nomination Status" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 10 );
        cell.setCellValue( "Nomination Date" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 11 );
        cell.setCellValue( "Points" );
        cell.setCellStyle( headerCellStyle );

        List<String> terms = compOffDate.retrieveTerm( quarter,year );

        List<Nomination> nominationList = nominationRepository.downloadNominaionDetails(statusList,terms);
        System.out.println(nominationList);
        int rownum = 1;
        for (Nomination nomination : nominationList) {
            row = sheet.createRow( rownum++ );
            createList( workbook, nomination, row );
        }
        return workbook;
    }


    private static void createList(XSSFWorkbook workbook, Nomination nomination, XSSFRow row) // creating cells for each row
    {
        Cell cell = row.createCell( 0 );
        cell.setCellValue( nomination.getNomineeName() );

        cell = row.createCell( 1 );
        cell.setCellValue( nomination.getNomineeId() );

        cell = row.createCell( 2 );
        cell.setCellValue( nomination.getManagerName() );

        cell = row.createCell( 3 );
        cell.setCellValue( nomination.getManagerId() );

        cell = row.createCell( 4 );
        cell.setCellValue( nomination.getNominatorName() );

        cell = row.createCell( 5 );
        cell.setCellValue( nomination.getNominatorid() );

        cell = row.createCell( 6 );
        cell.setCellValue( nomination.getLob() );

        cell = row.createCell( 7 );
        cell.setCellValue( nomination.getTerm() );

        cell = row.createCell( 8 );
        cell.setCellValue( nomination.getRewardType() );

        cell = row.createCell( 9 );
        cell.setCellValue( nomination.getNominationStatus() );

        cell = row.createCell( 10 );
        cell.setCellValue( nomination.getNominationDate() );
        CreationHelper creationHelper = workbook.getCreationHelper();
        CellStyle style1 = workbook.createCellStyle();
        style1.setDataFormat( creationHelper.createDataFormat().getFormat( "yyyy-MM-dd" ) );
        cell.setCellStyle( style1 );

        cell = row.createCell( 11 );
        cell.setCellValue( nomination.getPoints() );
    }
}

