package main.util;

import main.bean.CompOffDetails;
import main.bean.EmployeeRole;
import main.service.EmployeeRoleService;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Component
public class CompOffExcelReader
{

    @Autowired
    private GetEmployeeRoleDetails getEmployeeRoleDetails;

    @Autowired
    private EmployeeRoleService employeeRoleService;


    public List<CompOffDetails> readCompOff(MultipartFile file) throws IOException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook(file.getInputStream());

        XSSFSheet xssfSheet = xssfWorkbook.getSheet("CompOff");
        Iterator iterator = xssfSheet.iterator();

        List<CompOffDetails> compOffDetails = new ArrayList<>();

        while (iterator.hasNext())
        {

            Row row = (Row) iterator.next();

            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            CompOffDetails compOffData = new CompOffDetails();
            int empId = (int) (row.getCell(0).getNumericCellValue());
            compOffData.setEmpId(empId);
            compOffData.setEmpName(row.getCell(1).getStringCellValue());
            compOffData.setStatus(row.getCell(2).getStringCellValue());
            compOffData.setAbsenseType(row.getCell(3).getStringCellValue());
            compOffData.setStartDate((int) (row.getCell(4).getNumericCellValue()));
            compOffData.setEndDate((int) (row.getCell(5).getNumericCellValue()));

//            Optional<EmployeeRole> employeeRole = Optional.of( new EmployeeRole() );
//            employeeRole = getEmployeeRoleDetails.getEmployeeDetails( empId );

           /* Optional<EmployeeRole> employeeRole = employeeRoleService.findById( empId );
            compOffData.setLob( employeeRole.get().getLob() );
            compOffData.setProjectId( employeeRole.get().getProjectId() );
            compOffData.setProjectName( employeeRole.get().getProjectName() );
            compOffData.setLocation( employeeRole.get().getLocation() );
            compOffData.setDeliveryManager( employeeRole.get().getDeliveryManager() );

            compOffDetails.add( compOffData );*/
        }
            return compOffDetails;
    }

}