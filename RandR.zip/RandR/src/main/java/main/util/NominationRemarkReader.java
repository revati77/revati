package main.util;

import main.bean.EmployeeRewards;
import main.bean.NominationRemark;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@Component
public class NominationRemarkReader {

    private static List<NominationRemark> nominationRemarkList;

    public List<NominationRemark> nominationRemarkReader(MultipartFile file, String rewardType) {

        switch (rewardType) {
            case "Client_Appreciation":
                clientAppreciationRemark(file);
                break;
            case "Innovation_Award":
                innovationAwardRemark(file);
                break;
            case "Outstanding_FLM_of_the_Quarter":
                flmQuarterRemark(file);
                break;
            case "Manager_of_the_Quarter":
                managerOfTheQuarterRemark(file);
                break;
            case "Program_of_the_Quarter":
                programOfTheQuarterRemark(file);
                break;
        }
        return nominationRemarkList;
    }

    NominationRemark nominationRemark = new NominationRemark();
   // Remarks for Client_Appreciation

    public List<NominationRemark> clientAppreciationRemark(MultipartFile file){




        return nominationRemarkList;
    }

    public List<NominationRemark> innovationAwardRemark(MultipartFile file){
        return nominationRemarkList;
    }

    public List<NominationRemark> flmQuarterRemark(MultipartFile file){
        return nominationRemarkList;
    }

    public List<NominationRemark> managerOfTheQuarterRemark(MultipartFile file){
        return nominationRemarkList;
    }

    public List<NominationRemark> programOfTheQuarterRemark(MultipartFile file){
        return nominationRemarkList;
    }
}
