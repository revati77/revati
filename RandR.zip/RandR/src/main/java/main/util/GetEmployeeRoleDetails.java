package main.util;

import main.bean.EmployeeRole;
import main.service.EmployeeRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GetEmployeeRoleDetails {

    @Autowired
    EmployeeRoleService employeeRoleService;

    @Autowired
    EmployeeRole employeeRole;

    List<EmployeeRole> employeeRoleList = new ArrayList<>();

    private void findAll() {
        employeeRoleList = employeeRoleService.findAll();
    }

    public Optional<EmployeeRole> getEmployeeDetails(int empId) {

        if (CollectionUtils.isEmpty(employeeRoleList)) {
            findAll();
        }
        Optional<EmployeeRole> employeeRoleDetail = employeeRoleList.stream().filter(employeeRoleData -> employeeRoleData.getEmpId().equals(empId)).findFirst();
        if (employeeRoleDetail.isPresent()) {
            return employeeRoleDetail;
        }
        return employeeRoleDetail;
    }
}
