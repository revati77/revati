package main.bean;
import org.springframework.stereotype.Component;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "employeecompoff")
public class EmployeeCompOff {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "COMPOFF_ID")
    private Long compOffId;
    @Column(name = "EMP_ID ")
    private Integer empId;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "COMPOFF_STATUS")
    private String compOffStatus;
    @Column(name = "ABSENCE_TYPE")
    private String absenseType;

    @Temporal(TemporalType.DATE)
    @Column(name = "START_DATE ")
    private Date startDate;

   @Temporal(TemporalType.DATE)
    @Column(name = "END_DATE ")
    private Date endDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "OFF_DAY ")
    private Date offDay;

    @Column(name = "LOB")
    private String lob;
    @Column(name = "PROJECT_ID ")
    private int projectId;
    @Column(name = "PROJECT_NAME")
    private String projectName;
    @Column(name = "LOCATION")
    private String location;
    @Column(name = "DELIVERY_MANAGER")
    private String deliveryManager;
    @Column(name = "ADVANCE_COMPOFF")
    private String advanceCompOff;
    @Column(name = "VOUCHER_STATUS")
    private String voucherStatus;
    @Column(name = "PART_OF_WEEKEND_INTERVIEW")
    private String partOfWeeekendInterview;
    @Column(name = "REASON")
    private String reason;
    @Column(name="COMMENTS")
    private String comments;

    public EmployeeCompOff() {
    }
    //getters and setters
    public Long getCompOffId() {
        return compOffId;
    }
    public void setCompOffId(Long compOffId) {
        this.compOffId = compOffId;
    }
    public Integer getEmpId() {
        return empId;
    }
    public void setEmpId(Integer empId) {
        this.empId = empId;
    }
    public String getEmpName() {
        return empName;
    }
    public void setEmpName(String empName) {
        this.empName = empName;
    }
    public String getCompOffStatus() {
        return compOffStatus;
    }
    public void setCompOffStatus(String compOffStatus) {
        this.compOffStatus = compOffStatus;
    }
    public String getAbsenseType() {
        return absenseType;
    }
    public void setAbsenseType(String absenseType) {
        this.absenseType = absenseType;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

     public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getOffDay() {
        return offDay;
    }

    public void setOffDay(Date offDay) {
        this.offDay = offDay;
    }

    public String getLob() {
        return lob;
    }
    public void setLob(String lob) {
        this.lob = lob;
    }
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getDeliveryManager() {
        return deliveryManager;
    }

    public void setDeliveryManager(String deliveryManager) {
        this.deliveryManager = deliveryManager;
    }

    public String getAdvanceCompOff() {
        return advanceCompOff;
    }
    public void setAdvanceCompOff(String advanceCompOff) {
        this.advanceCompOff = advanceCompOff;
    }
    public String getVoucherStatus() {
        return voucherStatus;
    }
    public void setVoucherStatus(String voucherStatus) {
        this.voucherStatus = voucherStatus;
    }
    public String getPartOfWeeekendInterview() {
        return partOfWeeekendInterview;
    }
    public void setPartOfWeeekendInterview(String partOfWeeekendInterview) {
        this.partOfWeeekendInterview = partOfWeeekendInterview;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}