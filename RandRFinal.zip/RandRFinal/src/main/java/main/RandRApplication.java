package main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.TimeZone;


@SpringBootApplication
public class RandRApplication {

    public static void main(String args[])throws Exception {
        SpringApplication.run( RandRApplication.class, args);
    }
}
