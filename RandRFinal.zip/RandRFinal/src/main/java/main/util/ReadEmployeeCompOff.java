package main.util;

import main.bean.EmployeeCompOff;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Component
public class ReadEmployeeCompOff {

    public List<EmployeeCompOff> readCompOff(MultipartFile compOffFile) throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook( compOffFile.getInputStream() );
        XSSFSheet xssfSheet = xssfWorkbook.getSheet( "CompOff" );
        Iterator iterator = xssfSheet.iterator();

        List<EmployeeCompOff> employeeCompOffList = new ArrayList<>();

        while (iterator.hasNext()) {
            Row row = (Row) iterator.next();
            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            EmployeeCompOff compOffData = new EmployeeCompOff();
            int empId = (int) (row.getCell( 0 ).getNumericCellValue());
            compOffData.setEmpId( empId );
            compOffData.setEmpName( row.getCell( 1 ).getStringCellValue() );
            compOffData.setCompOffStatus( row.getCell( 2 ).getStringCellValue() );
            compOffData.setAbsenseType( row.getCell( 3 ).getStringCellValue() );

            String date1 = row.getCell(6).getStringCellValue();
            Date date2 =new SimpleDateFormat("yyyy-MM-dd").parse(date1);
            compOffData.setStartDate(date2);

            String date3 = row.getCell(6).getStringCellValue();
            Date date4 =new SimpleDateFormat("yyyy-MM-dd").parse(date3);
            compOffData.setEndDate(date4);

            String date5 = row.getCell(6).getStringCellValue();
            Date date6 =new SimpleDateFormat("yyyy-MM-dd").parse(date5);
            compOffData.setOffDay(date6);

          /*  compOffData.setStartDate( (int) (row.getCell( 4 ).getNumericCellValue()) );
            compOffData.setEndDate( (int) (row.getCell( 5 ).getNumericCellValue()) );
            compOffData.setOffDay( (int) (row.getCell( 6 ).getNumericCellValue()) );*/

            employeeCompOffList.add( compOffData );
        }
        return employeeCompOffList;
    }
}
