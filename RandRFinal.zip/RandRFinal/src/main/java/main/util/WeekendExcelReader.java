package main.util;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Component
public class WeekendExcelReader {

    /*  public static void main(String[] args) throws IOException {
           ExcelReader excelReader = new ExcelReader();
           excelReader.read();
       }
     */

    @Autowired
    EmployeeRewardRepository employeeRewardRepository;

    @Autowired
    CalculatePoints calculatePoints;

    public List<EmployeeReward> read(MultipartFile file, Integer empId) throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook(file.getInputStream());

        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook( new FileInputStream( new File( "C:\\Users\\rashmi.n\\RandR\\Excel\\sample.xlsx" ) ) );
        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook(new FileInputStream(new File("C:\\CodeBase\\Rashu\\Employees.xlsx")));
        XSSFSheet xssfSheet = xssfWorkbook.getSheet("employee");
        Iterator iterator = xssfSheet.iterator();
        //HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new FileInputStream(new File("C:\\Users\\rashmi.n\\RandR\\sample.xlsx")));
        //HSSFSheet hssfSheet = hssfWorkbook.getSheet("employee");
        //Iterator iterator = hssfSheet.iterator();

        List<EmployeeReward> employeeEntities = new ArrayList<>();

        while (iterator.hasNext()) {

            Row row = (Row) iterator.next();

            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            EmployeeReward employeeReward = new EmployeeReward();

            employeeReward.setEmpId((int) row.getCell(0).getNumericCellValue());
            employeeReward.setEmpName(row.getCell(1).getStringCellValue());
            employeeReward.setRewardType(row.getCell(2).getStringCellValue());
            employeeReward.setSkill(row.getCell(3).getStringCellValue());
            employeeReward.setLocation(row.getCell(4).getStringCellValue());
            int noOfInterviews = new Double(row.getCell(5).getNumericCellValue()).intValue();
            employeeReward.setNoOfInterviews(noOfInterviews);

            String date1 = row.getCell(6).getStringCellValue();
            Date date2 =new SimpleDateFormat("yyyy-MM-dd").parse(date1);
            employeeReward.setDateOf(date2);

        /*    String date_of = row.getCell(6).getStringCellValue();
            DateTimeFormatter simpleDateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            DateTimeFormatter simpleDateFormat1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            employeeReward.setDateOf(LocalDate.parse(date_of, simpleDateFormat).format(simpleDateFormat1));*/

            int managerId = new Double(row.getCell(7).getNumericCellValue()).intValue();
            employeeReward.setManagerId(managerId);

            Integer points = calculatePoints.calculateTotalPoints( employeeReward.getRewardType(), employeeReward.getNoOfInterviews());
            employeeReward.setNoOfPoints(points);
            employeeReward.setCreatedby(empId);
            employeeReward.setModifiedBy(empId);
            employeeReward.setAdvanceCompoff("No");
            employeeReward.setStatus("Pending");
            employeeReward.setEligibleForCompoff("Yes");

            employeeEntities.add( employeeReward );
        }
        employeeRewardRepository.saveAll(employeeEntities);
        return employeeEntities;
    }

}
