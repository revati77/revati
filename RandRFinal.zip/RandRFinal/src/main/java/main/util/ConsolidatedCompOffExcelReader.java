package main.util;

import main.bean.EmployeeCompOff;
import main.bean.EmployeeProjectInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@Component
public class ConsolidatedCompOffExcelReader {

    @Autowired
    private ReadEmployeeCompOff readEmployeeCompOff;

    @Autowired
    private ReadEmployeeProjectDetails readEmployeeProjectDetails;

    public List<EmployeeCompOff> readExcelCompOff(MultipartFile compOffFile, MultipartFile employeeProjectExcel) throws IOException, ParseException {

        //Read Employee CompOff Excel
        List<EmployeeCompOff> employeeCompOffList = readEmployeeCompOff.readCompOff(compOffFile);

        // Read Employee Project Detail Excel
        List<EmployeeProjectInfo> employeeProjectInfoList=readEmployeeProjectDetails.readEmployeeProjectDetails( employeeProjectExcel );

        for (EmployeeCompOff employeeCompOff : employeeCompOffList){

            int empId=employeeCompOff.getEmpId();

            Optional<EmployeeProjectInfo> employeeProjectInfo = null;
            employeeProjectInfo = employeeProjectInfoList.stream().filter( employeeProjectInfoData -> employeeProjectInfoData.getEmpId().equals(empId)).findFirst();
            if (employeeProjectInfo.isPresent()){

                employeeCompOff.setLob( employeeProjectInfo.get().getLob());
                employeeCompOff.setProjectId(employeeProjectInfo.get().getProjectId() );
                employeeCompOff.setProjectName(employeeProjectInfo.get().getProjectName());
                employeeCompOff.setLocation( employeeProjectInfo.get(). getLocation());
                employeeCompOff.setDeliveryManager( employeeProjectInfo.get().getDeliveryManager() );
            }
        }
        return employeeCompOffList;
    }
}