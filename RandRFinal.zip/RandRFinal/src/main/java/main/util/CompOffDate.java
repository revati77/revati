package main.util;

import main.bean.EmployeeReward;
import main.bean.Nomination;
import main.repository.EmployeeRewardRepository;
import main.repository.NominationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class CompOffDate {

    @Autowired
    private EmployeeRewardRepository  employeeRewardRepository;

    @Autowired
    private NominationRepository nominationRepository;



    public List<EmployeeReward> retrieveByDate(Integer empId, Date date1)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        c.add(Calendar.MONTH, -3);
        Date date2= c.getTime();
        System.out.print(date1);
        System.out.print(date2);
        return employeeRewardRepository.toGetByQuarterDate(empId,date1,date2);
    }

    public void getQuarterList(String qName, Integer year)
    {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.set(Calendar.YEAR,year);
        c2.set(Calendar.YEAR,year);
        if(qName.equals("Q1"))
        {
            c1.set(Calendar.MONTH,3);
            c2.set(Calendar.MONTH,5);
            c1.set(Calendar.DAY_OF_MONTH,1);
            c2.set(Calendar.DAY_OF_MONTH,30);
            Date date1= c1.getTime();
            Date date2= c2.getTime();
            List<EmployeeReward> employeeRewardList=employeeRewardRepository.getQuarterList(date1,date2);
            List<Nomination> nominationList=nominationRepository.getQuarterList(date1,date2);
            System.out.println(employeeRewardList);
            System.out.println(nominationList);
        }

        if(qName.equals("Q2"))
        {
            c1.set(Calendar.MONTH,6);
            c2.set(Calendar.MONTH,8);
            c1.set(Calendar.DAY_OF_MONTH,1);
            c2.set(Calendar.DAY_OF_MONTH,30);
            Date date1= c1.getTime();
            Date date2= c2.getTime();
            List<EmployeeReward> employeeRewardList=employeeRewardRepository.getQuarterList(date1,date2);
            List<Nomination> nominationList=nominationRepository.getQuarterList(date1,date2);
            System.out.println(employeeRewardList);
            System.out.println(nominationList);
        }

        if(qName.equals("Q3"))
        {
            c1.set(Calendar.MONTH,9);
            c2.set(Calendar.MONTH,11);
            c1.set(Calendar.DAY_OF_MONTH,1);
            c2.set(Calendar.DAY_OF_MONTH,31);
            Date date1= c1.getTime();
            Date date2= c2.getTime();
            List<EmployeeReward> employeeRewardList=employeeRewardRepository.getQuarterList(date1,date2);
            List<Nomination> nominationList=nominationRepository.getQuarterList(date1,date2);
            System.out.println(employeeRewardList);
            System.out.println(nominationList);
        }

        if(qName.equals("Q4"))
        {
            c1.set(Calendar.MONTH,0);
            c2.set(Calendar.MONTH,2);
            c1.set(Calendar.DAY_OF_MONTH,1);
            c2.set(Calendar.DAY_OF_MONTH,31);
            Date date1= c1.getTime();
            Date date2= c2.getTime();
            List<EmployeeReward> employeeRewardList=employeeRewardRepository.getQuarterList(date1,date2);
            List<Nomination> nominationList=nominationRepository.getQuarterList(date1,date2);
            System.out.println(employeeRewardList);
            System.out.println(nominationList);
        }
    }
}
