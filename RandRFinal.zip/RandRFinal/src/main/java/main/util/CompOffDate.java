package main.util;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
public class CompOffDate {

    @Autowired
    private EmployeeRewardRepository  employeeRewardRepository;

    public List<EmployeeReward> retrieveByDate(Integer empId, Date date1)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        c.add(Calendar.MONTH, -3);
        Date date2= c.getTime();
        System.out.print(date1);
        System.out.print(date2);
        return employeeRewardRepository.toGetByQuarterDate(empId,date1,date2);
    }
}
