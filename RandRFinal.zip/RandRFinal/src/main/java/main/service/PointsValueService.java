package main.service;

import main.bean.PointsValue;
import main.repository.PointsValueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PointsValueService {
    @Autowired
    private PointsValueRepository pointsValueRepository;

    // to save
    public PointsValue save(PointsValue pointsValue) {
        return pointsValueRepository.save( pointsValue );
    }

    // to get all
    public List<PointsValue> getAll() {
        return pointsValueRepository.findAll();
    }

    // to get by id
    public PointsValue findByRewardType(String reward_type) {
        return pointsValueRepository.findByRewardType( reward_type );
    }

    //    to update
    public PointsValue update(PointsValue pointsValue) {
        return pointsValueRepository.save( pointsValue );
    }

    //to delete
    public void delete(Integer pointsId) {
        pointsValueRepository.deleteById( pointsId );
    }
}
