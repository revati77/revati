package com.example.demo.repository;

import com.example.demo.model.NominationCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import java.util.List;


public interface NominationCriteriaRepository extends JpaRepository<NominationCriteria,Integer> {
    @Query("select r from NominationCriteria r where r.REWARD_TYPE=?1")
    List<NominationCriteria> findByRewardType(String reward_type);
}
