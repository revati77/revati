package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name="nominationremark",catalog = "randr")
public class NominationRemark {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer REMARK_ID;

    private Long ID;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID", insertable = false,updatable = false)
    private NominationEntity nomination;

    /*private Integer CRITERIA_ID;
    @ManyToOne(fetch = FetchType.LAZY)
    private NominationCriteria nominationcriteria;*/

    private String REMARK;

    public NominationRemark() {
    }

    public Integer getREMARK_ID() {
        return REMARK_ID;
    }

    public void setREMARK_ID(Integer REMARK_ID) {
        this.REMARK_ID = REMARK_ID;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public NominationEntity getNomination() {
        return nomination;
    }

    public void setNomination(NominationEntity nomination) {
        this.nomination = nomination;
    }

    public String getREMARK() {
        return REMARK;
    }

    public void setREMARK(String REMARK) {
        this.REMARK = REMARK;
    }
}
