package com.example.demo.service;

import com.example.demo.model.Employeerole;
import com.example.demo.repository.EmployeeroleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeroleService {

    @Autowired
    private EmployeeroleRepository employeeroleRepository;

/*    To save */
    public Employeerole save(Employeerole employeerole)
    {
        return employeeroleRepository.save(employeerole);
    }

   /* retrieve all employeerole details*/
    public List<Employeerole> findAll()
    {
        return employeeroleRepository.findAll();
    }

/*    Get by an id*/
    public Optional<Employeerole> findById(Integer EMP_ID)
    {
        return employeeroleRepository.findById(EMP_ID);
    }

/*    to update*/
    public Employeerole update(Employeerole employeerole) {
        return employeeroleRepository.save(employeerole);
    }
}
