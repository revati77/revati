package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="pointsvalue",catalog = "randr")
public class Points {

    @Id
    private String REWARD_TYPE;
    private Integer POINTS;
    private Date MODIFIED_DATE;
    private Integer MODIFIED_BY;

    public Date getMODIFIED_DATE() {
        return MODIFIED_DATE;
    }

    public void setMODIFIED_DATE(Date MODIFIED_DATE) {
        this.MODIFIED_DATE = MODIFIED_DATE;
    }

    public Integer getMODIFIED_BY() {
        return MODIFIED_BY;
    }

    public void setMODIFIED_BY(Integer MODIFIED_BY) {
        this.MODIFIED_BY = MODIFIED_BY;
    }

    public String getREWARD_TYPE() {

        return REWARD_TYPE;
    }

    public void setREWARD_TYPE(String REWARD_TYPE) {

        this.REWARD_TYPE = REWARD_TYPE;
    }

    public Integer getPOINTS() {

        return POINTS;
    }

    public void setPOINTS(Integer POINTS) {

        this.POINTS = POINTS;
    }

    public Points() {
    }
}
