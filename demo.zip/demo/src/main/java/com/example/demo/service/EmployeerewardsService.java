package com.example.demo.service;

import com.example.demo.model.EmployeeEntity;
import com.example.demo.repository.EmployeerewardsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeerewardsService {

    @Autowired
    private EmployeerewardsRepository employeerewardsRepository;

    /*    To save */
    public EmployeeEntity save(EmployeeEntity employeeEntity)

    {
        return employeerewardsRepository.save(employeeEntity);
    }

    /* retrieve all employeerole details*/
    public List<EmployeeEntity> findAll()

    {
        return employeerewardsRepository.findAll();
    }

    /*    Get by an id*/
    public Optional<EmployeeEntity> getId(Integer EMP_ID)
    {
        return  employeerewardsRepository.findByEmpid(EMP_ID);

    }

    /*    to update*/
    public EmployeeEntity update(EmployeeEntity employeeEntity)
    {
        return employeerewardsRepository.save(employeeEntity);
    }
}
