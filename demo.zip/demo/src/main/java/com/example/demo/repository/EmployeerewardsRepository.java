package com.example.demo.repository;


import com.example.demo.model.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface EmployeerewardsRepository extends JpaRepository<EmployeeEntity,Integer> {
    @Query("select e from EmployeeEntity e where e.EMP_ID=?1")
    Optional<EmployeeEntity> findByEmpid(Integer EMP_ID);
}
