package com.example.demo.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "employeerewards")
public class EmployeeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) Long EID;
    private Integer EMP_ID;
    private String EMP_NAME;
    private String REWARD_TYPE;
    private Integer NO_OF_INTERVIEWS;
    private Integer NO_OF_POINTS;
    private Date DATE_OF;
    private Integer CREATED_BY;
    private Integer MODIFIED_BY;
    private Integer MANAGER_ID;
    private String ADVANCE_COMPOFF;
    private String STATUS;
    private String ELIGIBLE_FOR_COMPOFF;

    public Integer getEMP_ID() {
        return EMP_ID;
    }

    public void setEMP_ID(Integer EMP_ID) {
        this.EMP_ID = EMP_ID;
    }

    public String getEMP_NAME() {
        return EMP_NAME;
    }

    public void setEMP_NAME(String EMP_NAME) {
        this.EMP_NAME = EMP_NAME;
    }

    public String getREWARD_TYPE() {
        return REWARD_TYPE;
    }

    public void setREWARD_TYPE(String REWARD_TYPE) {
        this.REWARD_TYPE = REWARD_TYPE;
    }

    public Integer getNO_OF_INTERVIEWS() {
        return NO_OF_INTERVIEWS;
    }

    public void setNO_OF_INTERVIEWS(Integer NO_OF_INTERVIEWS) {
        this.NO_OF_INTERVIEWS = NO_OF_INTERVIEWS;
    }

    public Integer getNO_OF_POINTS() {
        return NO_OF_POINTS;
    }

    public void setNO_OF_POINTS(Integer NO_OF_POINTS) {
        this.NO_OF_POINTS = NO_OF_POINTS;
    }

    public Date getDATE_OF() {
        return DATE_OF;
    }

    public void setDATE_OF(Date DATE_OF) {
        this.DATE_OF = DATE_OF;
    }

    public Integer getCREATED_BY() {
        return CREATED_BY;
    }

    public void setCREATED_BY(Integer CREATED_BY) {
        this.CREATED_BY = CREATED_BY;
    }

    public Integer getMODIFIED_BY() {
        return MODIFIED_BY;
    }

    public void setMODIFIED_BY(Integer MODIFIED_BY) {
        this.MODIFIED_BY = MODIFIED_BY;
    }

    public Integer getMANAGER_ID() {
        return MANAGER_ID;
    }

    public void setMANAGER_ID(Integer MANAGER_ID) {
        this.MANAGER_ID = MANAGER_ID;
    }

    public String getADVANCE_COMPOFF() {
        return ADVANCE_COMPOFF;
    }

    public void setADVANCE_COMPOFF(String ADVANCE_COMPOFF) {
        this.ADVANCE_COMPOFF = ADVANCE_COMPOFF;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getELIGIBLE_FOR_COMPOFF() {
        return ELIGIBLE_FOR_COMPOFF;
    }

    public void setELIGIBLE_FOR_COMPOFF(String ELIGIBLE_FOR_COMPOFF) {
        this.ELIGIBLE_FOR_COMPOFF = ELIGIBLE_FOR_COMPOFF;
    }

    public EmployeeEntity() {
    }

    @Override
    public String toString() {
        return "EmployeeEntity{" +
                "EMP_ID=" + EMP_ID +
                ", EMP_NAME='" + EMP_NAME + '\'' +
                ", REWARD_TYPE='" + REWARD_TYPE + '\'' +
                ", NO_OF_INTERVIEWS=" + NO_OF_INTERVIEWS +
                ", NO_OF_POINTS=" + NO_OF_POINTS +
                ", DATE_OF=" + DATE_OF +
                ", CREATED_BY=" + CREATED_BY +
                ", MODIFIED_BY=" + MODIFIED_BY +
                ", MANAGER_ID=" + MANAGER_ID +
                ", ADVANCE_COMPOFF='" + ADVANCE_COMPOFF + '\'' +
                ", STATUS='" + STATUS + '\'' +
                ", ELIGIBLE_FOR_COMPOFF='" + ELIGIBLE_FOR_COMPOFF + '\'' +
                '}';
    }
}

