package com.example.demo.controller;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Employeerole;
import com.example.demo.repository.EmployeeroleRepository;
import com.example.demo.service.EmployeeroleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/emprole")
public class EmployeeroleController {

    @Autowired
    private EmployeeroleService employeeroleService;

  /*  to save*/
    @PostMapping("/save")
    public  Employeerole createEmployee(@Valid @RequestBody Employeerole employeerole)
    {
        return employeeroleService.save(employeerole);
    }

   /* to retrieve all details*/
    @GetMapping("/all")
    public List<Employeerole> getAll()
   {
       return employeeroleService.findAll();
   }

 /*  to retrieve by id*/
    @GetMapping("/getByid/{EMP_ID}")
    public Optional<Employeerole> getId(@PathVariable("EMP_ID") final Integer EMP_ID)
   {
        return employeeroleService.findById(EMP_ID);
   }

 /*  to update*/
    @PutMapping("/update")
    public Employeerole update(@RequestBody Employeerole employeerole)
    {
        return  employeeroleService.update(employeerole);
    }
}
