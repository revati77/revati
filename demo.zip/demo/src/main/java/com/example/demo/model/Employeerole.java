package com.example.demo.model;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="employeerole",catalog = "randr")
public class Employeerole {

    @Id
    private Integer EMP_ID;
    private String EMP_NAME;
    private String EMP_ROLE;
    private Integer MANAGER_ID;
    private String PASSWORD;

    //Getters and Setters and Constructor

    public Employeerole() {
    }

    public Integer getEMP_ID() {
        return EMP_ID;
    }

    public void setEMP_ID(Integer EMP_ID) {
        this.EMP_ID = EMP_ID;
    }

    public String getEMP_NAME() {
        return EMP_NAME;
    }

    public void setEMP_NAME(String EMP_NAME) {
        this.EMP_NAME = EMP_NAME;
    }

    public String getEMP_ROLE() {
        return EMP_ROLE;
    }

    public void setEMP_ROLE(String EMP_ROLE) {
        this.EMP_ROLE = EMP_ROLE;
    }

    public Integer getMANAGER_ID() {
        return MANAGER_ID;
    }

    public void setMANAGER_ID(Integer MANAGER_ID) {
        this.MANAGER_ID = MANAGER_ID;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public Employeerole(Integer EMP_ID, String EMP_NAME, String EMP_ROLE, Integer MANAGER_ID, String PASSWORD) {
        this.EMP_ID = EMP_ID;
        this.EMP_NAME = EMP_NAME;
        this.EMP_ROLE = EMP_ROLE;
        this.MANAGER_ID = MANAGER_ID;
        this.PASSWORD = PASSWORD;
    }


}
