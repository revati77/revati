package com.example.demo.controller;


import com.example.demo.model.EmployeeEntity;
import com.example.demo.service.EmployeerewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/Emprewards")
public class EmployeerewardsController {

    @Autowired
    private EmployeerewardsService employeerewardsService;

    /*  to save*/
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeEntity createEmployee(@Valid @RequestBody EmployeeEntity employeeEntity)
    {
        return employeerewardsService.save(employeeEntity);
    }

    /* to retrieve all details*/
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeEntity> getAll()
    {
        return employeerewardsService.findAll();
    }

    /*  to retrieve by id*/
    @GetMapping("/getByid/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<EmployeeEntity> getId(@PathVariable("EMP_ID") final Integer EMP_ID)
    {
        return employeerewardsService.getId(EMP_ID);
    }

    /*  to update*/
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeEntity update(@RequestBody EmployeeEntity employeeEntity)
    {
        return  employeerewardsService.update(employeeEntity);
    }
}
