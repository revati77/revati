package com.example.demo.service;

import com.example.demo.model.NominationEntity;
import com.example.demo.repository.NominationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NominationService {

    @Autowired
    private NominationRepository nominationRepository;
/*    To save */


    public NominationEntity save(NominationEntity nominationEntity)

    {
        return nominationRepository.save(nominationEntity);
    }

/* retrieve all employeerole details*/


    public List<NominationEntity> findAll()

    {
        return nominationRepository.findAll();
    }

/*    Get by an id*/


    public Optional<NominationEntity> getId(Integer NOMINEE_ID)
    {
        return  nominationRepository.findByNomineeid(NOMINEE_ID);

    }

 /*   to update*/


    public NominationEntity update(NominationEntity nominationEntity)
    {
        return nominationRepository.save(nominationEntity);
    }
}
