package com.example.demo.repository;

import com.example.demo.model.Nomination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface NominationRepository extends JpaRepository<Nomination,Long> {
    @Query("select n from Nomination n where n.nomineeId=?1")
    Optional<Nomination> findByNomineeid(Integer nominee_id);
}
