package com.example.demo.service;

import com.example.demo.model.EmployeeRewards;
import com.example.demo.repository.EmployeeRewardsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRewardsService {

    @Autowired
    private EmployeeRewardsRepository employeerewardsRepository;

    /*    To save */
    public EmployeeRewards save(EmployeeRewards employeeRewards)


    {
        return employeerewardsRepository.save(employeeRewards);
    }

    /* retrieve all employeerole details*/
    public List<EmployeeRewards> findAll()

    {
        return employeerewardsRepository.findAll();
    }

    /*    Get by an id*/ public Optional<EmployeeRewards> getId(Integer empId)
    {
        return  employeerewardsRepository.findByEmpid(empId);

    }


    /*    to update*/
    public EmployeeRewards update(EmployeeRewards employeeRewards)
    {
        return employeerewardsRepository.save(employeeRewards);
    }

    //To delete all
    public void delete(Long id)
    {
        employeerewardsRepository.deleteById(id);
    }

}
