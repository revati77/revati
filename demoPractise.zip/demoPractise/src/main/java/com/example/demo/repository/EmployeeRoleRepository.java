package com.example.demo.repository;

import com.example.demo.model.EmployeeRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface EmployeeRoleRepository extends JpaRepository<EmployeeRole,Integer> {

    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeRole WHERE empId = ?1")
    void deleteById(Integer empId);
}
