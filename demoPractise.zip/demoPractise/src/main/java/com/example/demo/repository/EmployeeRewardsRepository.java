package com.example.demo.repository;


import com.example.demo.model.EmployeeRewards;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.Optional;

public interface EmployeeRewardsRepository extends JpaRepository<EmployeeRewards,Long> {
    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeRewards WHERE id = ?1")
    void deleteById(Long id);

    @Query(value = "select e from EmployeeRewards e where e.empId=?1")
    Optional<EmployeeRewards> findByEmpid(Integer empId);



}
