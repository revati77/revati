package com.example.demo.controller;


import com.example.demo.model.EmployeeRole;
import com.example.demo.service.EmployeeRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/emprole")
public class EmployeeRoleController {

    @Autowired
    private EmployeeRoleService employeeroleService;

  /*  to save*/
    @PostMapping("/save")
    public EmployeeRole createEmployee(@Valid @RequestBody EmployeeRole employeerole)
    {
        return employeeroleService.save(employeerole);
    }

   /* to retrieve all details*/
    @GetMapping("/all")
    public List<EmployeeRole> getAll()
   {
       return employeeroleService.findAll();
   }

 /*  to retrieve by id*/
    @GetMapping("/getByid/{EMP_ID}")
    public Optional<EmployeeRole> getId(@PathVariable("EMP_ID") final Integer EMP_ID)
   {
        return employeeroleService.findById(EMP_ID);
   }

 /*  to update*/
    @PutMapping("/update")
    public EmployeeRole update(@RequestBody EmployeeRole employeerole)
    {
        return  employeeroleService.update(employeerole);
    }

    //To delete
    @DeleteMapping("/deleteByid/{EMP_ID}")
    public void delete(@PathVariable("EMP_ID") final Integer empId) {
        employeeroleService.delete(empId);
    }
}
