package com.example.demo.controller;

import com.example.demo.model.Nomination;
import com.example.demo.service.NominationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/nomination")
public class NominationController {

    @Autowired
    private NominationService nominationService;

/*  to save*/

    @PostMapping("/save")
    public Nomination createEmployee(@Valid @RequestBody Nomination nomination)
    {
        return nominationService.save(nomination);
    }

/* to retrieve all details*/

    @GetMapping("/all")
    public List<Nomination> getAll()
    {
        return nominationService.findAll();
    }

/*  to retrieve by id*/

    @GetMapping("/getByid/{NOMINEE_ID}")
    public Optional<Nomination> getId(@PathVariable("NOMINEE_ID") final Integer nomineeId)
    {
        return nominationService.getId(nomineeId);
    }


/*  to update*/

    @PutMapping("/update")
    public Nomination update(@RequestBody Nomination nomination)
    {
        return  nominationService.update(nomination);
    }
}
