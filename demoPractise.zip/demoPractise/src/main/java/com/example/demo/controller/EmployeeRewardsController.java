package com.example.demo.controller;


import com.example.demo.model.EmployeeRewards;
import com.example.demo.service.EmployeeRewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/Emprewards")
public class EmployeeRewardsController {

    @Autowired
    private EmployeeRewardsService employeerewardsService;

    /*  to save*/
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeRewards createEmployee(@Valid @RequestBody EmployeeRewards employeeRewards)
    {
        return employeerewardsService.save(employeeRewards);
    }

    /* to retrieve all details*/
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeRewards> getAll()
    {
        return employeerewardsService.findAll();
    }

    /*  to retrieve by id*/
    @GetMapping("/getByid/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<EmployeeRewards> getId(@PathVariable("EMP_ID") final Integer empId)
    {
        return employeerewardsService.getId(empId);
    }

    /*  to update*/
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeRewards update(@RequestBody EmployeeRewards employeeRewards)
    {
        return  employeerewardsService.update(employeeRewards);
    }


    //To delete
    @DeleteMapping("/deleteByid/{ID}")
    public void delete(@PathVariable("ID") final Long id)
    {
        employeerewardsService.delete(id);
    }
}
