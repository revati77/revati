package com.example.demo.repository;

import com.example.demo.model.NominationCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;


public interface NominationCriteriaRepository extends JpaRepository<NominationCriteria,Integer> {
    @Modifying
    @Transactional
    @Query(value="DELETE FROM NominationCriteria WHERE criteriaId = ?1")
    void deleteById(Integer criteriaId);

    @Query(value = "select e from NominationCriteria e where e.rewardType=?1")
    List<NominationCriteria> findByRewardType(String rewardType);

    @Query(value = "select e from NominationCriteria e where e.criteriaId=?1")
    List<NominationCriteria> findByCriteriaId(Integer criteriaId);

}
