package com.example.demo.repository;

import com.example.demo.model.PointsValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.Optional;

public interface PointsValueRepository extends JpaRepository<PointsValue,String> {
    @Modifying
    @Transactional
    @Query(value="DELETE FROM PointsValue WHERE pointsId = ?1")
    void deleteById(Integer pointsId);

    @Query(value ="SELECT e FROM PointsValue e WHERE e.rewardType = ?1")
    Optional<PointsValue> findByRewardType(String rewardType);


}
