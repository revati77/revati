package com.example.demo.controller;

import com.example.demo.model.NominationRemark;
import com.example.demo.service.NominationRemarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/NominationRemark")
public class NominationRemarkController {

    @Autowired
    private NominationRemarkService nominationRemarkService;

/*  to save*/
    @PostMapping("/save")
    public NominationRemark createEmployee(@Valid @RequestBody NominationRemark nominationRemark)
    {
        return nominationRemarkService.save(nominationRemark);
    }

/* to retrieve all details*/

    @GetMapping("/all")
    public List<NominationRemark> getAll()
    {
        return nominationRemarkService.findAll();
    }

/*  to retrieve by id*/
    @GetMapping("/getByid/{REMARK_ID}")
    public Optional<NominationRemark> getId(@PathVariable("ID") final Integer remarkId)
    {
        return nominationRemarkService.getId(remarkId);
    }


/*  to update*/
    @PutMapping("/update")
    public NominationRemark update(@RequestBody NominationRemark nominationRemark)
    {
        return  nominationRemarkService.update(nominationRemark);
    }
}
