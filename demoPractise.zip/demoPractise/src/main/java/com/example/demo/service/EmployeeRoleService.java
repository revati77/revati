package com.example.demo.service;

import com.example.demo.model.EmployeeRole;
import com.example.demo.repository.EmployeeRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRoleService {

    @Autowired
    private EmployeeRoleRepository employeeroleRepository;

/*    To save */
    public EmployeeRole save(EmployeeRole employeerole)
    {
        return employeeroleRepository.save(employeerole);
    }

   /* retrieve all employeerole details*/
    public List<EmployeeRole> findAll()
    {
        return employeeroleRepository.findAll();
    }

/*    Get by an id*/
    public Optional<EmployeeRole> findById(Integer EMP_ID)
    {
        return employeeroleRepository.findById(EMP_ID);
    }

/*    to update*/
    public EmployeeRole update(EmployeeRole employeerole)
    {
        return employeeroleRepository.save(employeerole);
    }

    //To delete all
    public void delete(Integer empId) {
        employeeroleRepository.deleteById(empId);
    }
}
