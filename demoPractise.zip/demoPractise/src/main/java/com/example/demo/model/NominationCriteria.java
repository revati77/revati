package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name = "nominationcriteria")
public class NominationCriteria {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "CRITERIA_ID")
    private Integer criteriaId;

    @Column(name = "REWARD_TYPE")
    private String rewardType;

    @Column(name = "CRITERIA")
    private String criteria;

    //Getters and Setters and Constructor

    public NominationCriteria() {
    }

    public Integer getCriteriaId() {
        return criteriaId;
    }

    public void setCriteriaId(Integer criteriaId) {
        this.criteriaId = criteriaId;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public String getCriteria() {
        return criteria;
    }

    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }

    @Override
    public String toString() {
        return "NominationCriteria{" +
                "criteriaId=" + criteriaId +
                ", rewardType='" + rewardType + '\'' +
                ", criteria='" + criteria + '\'' +
                '}';
    }
}
