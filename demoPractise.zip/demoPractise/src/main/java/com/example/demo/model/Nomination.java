package com.example.demo.model;

import com.example.demo.model.NominationRemark;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "nomination", catalog = "randr")
public class Nomination {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "nomination")
    private List<NominationRemark> nominationRemarkList;
    @Column(name = "NOMINEE_NAME")
    private String nomineeName;
    @Column(name = "NOMINEE_ID")
    private Integer nomineeId;
    @Column(name = "MANAGER_NAME")
    private String managerName;
    @Column(name = "MANAGER_ID")
    private Integer managerId;
    @Column(name = "NOMINATOR_NAME")
    private String nominatorName;
    @Column(name = "NOMINATOR_ID")
    private Integer nominatorid;
    @Column(name = "LOB")
    private String lob;
    @Column(name = "TERM")
    private String term;
    @Column(name = "REWARD_TYPE")
    private String rewardType;
    @Column(name = "NOMINATION_STATUS")
    private String nominationStatus;
    @Column(name = "NOMINATION_DATE")
    private Date nominationDate;
    @Column(name = "PMO_ID")
    private Integer pmoId;

    //Getters and Setters and Constructor


    public Nomination() {
    }

    public List<NominationRemark> getNominationRemarkList() {
        return nominationRemarkList;
    }

    public void setNominationRemarkList(List<NominationRemark> nominationRemarkList) {
        this.nominationRemarkList = nominationRemarkList;
    }

    public Long getId() {
        return id;
    }

    public String getNomineeName() {
        return nomineeName;
    }

    public void setNomineeName(String nomineeName) {
        this.nomineeName = nomineeName;
    }

    public Integer getNomineeId() {
        return nomineeId;
    }

    public void setNomineeId(Integer nomineeId) {
        this.nomineeId = nomineeId;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    public String getNominatorName() {
        return nominatorName;
    }

    public void setNominatorName(String nominatorName) {
        this.nominatorName = nominatorName;
    }

    public Integer getNominatorid() {
        return nominatorid;
    }

    public void setNominatorid(Integer nominatorid) {
        this.nominatorid = nominatorid;
    }

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(String rewardType) {
        this.rewardType = rewardType;
    }

    public String getNominationStatus() {
        return nominationStatus;
    }

    public void setNominationStatus(String nominationStatus) {
        this.nominationStatus = nominationStatus;
    }

    public Date getNominationDate() {
        return nominationDate;
    }

    public void setNominationDate(Date nominationDate) {
        this.nominationDate = nominationDate;
    }

    public Integer getPmoId() {
        return pmoId;
    }

    public void setPmoId(Integer pmoId) {
        this.pmoId = pmoId;
    }
}
