package com.example.demo.service;

import com.example.demo.model.NominationCriteria;
import com.example.demo.repository.NominationCriteriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NominationCriteriaService {

    @Autowired
    private NominationCriteriaRepository nominationCriteriaRepository;

/*To save*/

    public NominationCriteria save(NominationCriteria nominationCriteria)

    {
        return nominationCriteriaRepository.save(nominationCriteria);
    }

/* retrieve all employeerole details*/

    public List<NominationCriteria> findAll()

    {
        return nominationCriteriaRepository.findAll();
    }

/*    Get by an REWARD_TYPE*/
public List<NominationCriteria> getByRewardType(String rewardType)
{
    return  nominationCriteriaRepository.findByRewardType(rewardType);

}



    /*    Get by an CriteriaId*/
    public List<NominationCriteria> getByCriteriaId(Integer criteriaId)
    {
        return  nominationCriteriaRepository.findByCriteriaId(criteriaId);

    }



/* to update*/

    public NominationCriteria update(NominationCriteria nominationCriteria)
    {
        return nominationCriteriaRepository.save(nominationCriteria);
    }

    //to delete
    public void delete(Integer criteriaId)
    {
        nominationCriteriaRepository.deleteById(criteriaId);
    }
}
