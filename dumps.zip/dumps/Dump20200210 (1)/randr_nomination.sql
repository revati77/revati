-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: randr
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nomination`
--

DROP TABLE IF EXISTS `nomination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nomination` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOMINEE_NAME` varchar(45) NOT NULL,
  `NOMINEE_ID` int(10) DEFAULT NULL,
  `MANAGER_NAME` varchar(45) DEFAULT NULL,
  `MANAGER_ID` int(10) DEFAULT NULL,
  `NOMINATOR_NAME` varchar(45) DEFAULT NULL,
  `NOMINATOR_ID` int(10) DEFAULT NULL,
  `LOB` varchar(45) DEFAULT NULL,
  `TERM` varchar(45) DEFAULT NULL,
  `REWARD_TYPE` varchar(45) DEFAULT NULL,
  `NOMINATION_STATUS` varchar(45) DEFAULT NULL,
  `NOMINATION_DATE` date DEFAULT NULL,
  `POINTS` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_index` (`NOMINEE_ID`,`LOB`,`TERM`,`REWARD_TYPE`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nomination`
--

LOCK TABLES `nomination` WRITE;
/*!40000 ALTER TABLE `nomination` DISABLE KEYS */;
INSERT INTO `nomination` VALUES (153,'Sarika Singh',2373950,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Client_Appreciation','Pending','2020-02-06',NULL),(154,'Pranjal Goyal',2370669,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Client_Appreciation','Pending','2020-02-06',NULL),(155,'Revati Reddy',2373950,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','06-2019','Client_Appreciation','Pending','2020-02-06',NULL),(156,'Aakash Tanwar',1234567,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Client_Appreciation','Pending','2020-02-06',NULL),(157,'Sarika Singh',2373950,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CIB','12-2019','Innovation_Award','Pending','2020-02-06',NULL),(158,'Pranjal Goyal',2370669,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CIB','11-2019','Innovation_Award','Pending','2020-02-06',NULL),(159,'Revati Reddi',2366400,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Innovation_Award','Pending','2020-02-06',NULL),(160,'Aakash Tanwar',1232345,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2020','Innovation_Award','Pending','2020-02-06',NULL),(161,'Sarika Singh',2373950,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Outstanding_FLM_of_the_Quarter','Pending','2020-02-06',NULL),(162,'Pranjal Goyal',2370669,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Outstanding_FLM_of_the_Quarter','Pending','2020-02-06',NULL),(163,'Revati Reddi',2366400,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Outstanding_FLM_of_the_Quarter','Pending','2020-02-06',NULL),(164,'Aakash Tanwar',1234567,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2020','Outstanding_FLM_of_the_Quarter','Pending','2020-02-06',NULL),(165,'Sarika Singh',2373950,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Manager_of_the_Quarter','Pending','2020-02-06',NULL),(166,'Pranjal Goyal',2370669,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Manager_of_the_Quarter','Pending','2020-02-06',NULL),(167,'Revati Reddi',2366400,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Manager_of_the_Quarter','Pending','2020-02-06',NULL),(168,'Aakash Tanwar',1234567,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Manager_of_the_Quarter','Pending','2020-02-06',NULL),(169,'Sarika Singh',2373950,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Program_of_the_Quarter','Pending','2020-02-06',NULL),(170,'Pranjal Goyal',2370669,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Program_of_the_Quarter','Pending','2020-02-06',NULL),(171,'Revati Reddi',2366400,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Program_of_the_Quarter','Pending','2020-02-06',NULL),(172,'Aakash Tanwar',1234567,'Rashmi M N',2347303,'AMEY JOSHI',1234567,'CCB','09-2019','Program_of_the_Quarter','Pending','2020-02-06',NULL);
/*!40000 ALTER TABLE `nomination` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-10 11:28:06
