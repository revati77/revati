-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: randr
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nominationremark`
--

DROP TABLE IF EXISTS `nominationremark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nominationremark` (
  `ID` int(11) NOT NULL,
  `CRITERIA_ID` int(11) NOT NULL,
  `REMARK` varchar(100) DEFAULT NULL,
  `REMARK_ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`REMARK_ID`),
  KEY `ID` (`ID`),
  KEY `CRITERIA_ID` (`CRITERIA_ID`),
  CONSTRAINT `FKg7vayl36s5a4ijckq1nb20fum` FOREIGN KEY (`ID`) REFERENCES `nomination` (`ID`),
  CONSTRAINT `nominationremark_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `nomination` (`ID`),
  CONSTRAINT `nominationremark_ibfk_2` FOREIGN KEY (`CRITERIA_ID`) REFERENCES `nominationcriteria` (`CRITERIA_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1234 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nominationremark`
--

LOCK TABLES `nominationremark` WRITE;
/*!40000 ALTER TABLE `nominationremark` DISABLE KEYS */;
INSERT INTO `nominationremark` VALUES (153,40,'R & R recognition Database',1066),(153,41,'Complex',1067),(153,42,'5',1068),(154,40,'R & R recognition Database',1069),(154,41,'Complex',1070),(154,42,'10',1071),(155,40,'R & R recognition Database',1072),(155,41,'Complex',1073),(155,42,'6',1074),(156,40,'R & R recognition Database',1075),(156,41,'Complex',1076),(156,42,'8',1077),(157,1,'Medium',1078),(157,2,'Automation of Award Nomination',1079),(157,3,'The time consumed for manual processing was reduced',1080),(157,4,'Process Automation ',1081),(157,5,'Ownership of Database creation',1082),(157,6,'Reduction in cost and time',1083),(157,7,'Application to be used for weekend interview consolidation and award nomination',1084),(157,8,'Good',1085),(158,1,'Complex',1086),(158,2,'Automation of Award Nomination',1087),(158,3,'The time consumed for manual processing was reduced',1088),(158,4,'Process Automation ',1089),(158,5,'Ownership of Frontend creation and Database design',1090),(158,6,'Reduction in cost and time',1091),(158,7,'Application to be used for weekend interview consolidation and award nomination',1092),(158,8,'Good',1093),(159,1,'Easy',1094),(159,2,'Automation of Award Nomination',1095),(159,3,'The time consumed for manual processing was reduced',1096),(159,4,'Process Automation ',1097),(159,5,'Ownership of backend creation',1098),(159,6,'Reduction in cost and time',1099),(159,7,'Application to be used for weekend interview consolidation and award nomination',1100),(159,8,'better',1101),(160,1,'Easy',1102),(160,2,'Automation of Award Nomination',1103),(160,3,'The time consumed for manual processing was reduced',1104),(160,4,'Process Automation ',1105),(160,5,'Ownership of backend creation',1106),(160,6,'Reduction in cost and time',1107),(160,7,'Application to be used for weekend interview consolidation and award nomination',1108),(160,8,'better',1109),(161,9,'Completed',1110),(161,10,'By reducing the time',1111),(161,11,'Reduction in cost',1112),(161,12,'Vey good',1113),(161,13,'By using Automation testing',1114),(161,14,'During development',1115),(161,15,'Yes',1116),(161,16,'60',1117),(161,17,'During testing',1118),(161,18,'No',1119),(161,19,'By working smarter',1120),(162,9,'Not Completed',1121),(162,10,'By reducing the time',1122),(162,11,'Reduction in cost',1123),(162,12,'Vey good',1124),(162,13,'By using Automation testing',1125),(162,14,'During development',1126),(162,15,'Yes',1127),(162,16,'50',1128),(162,17,'During testing',1129),(162,18,'No',1130),(162,19,'By working smarter',1131),(163,9,'Completed',1132),(163,10,'By reducing the time',1133),(163,11,'Reduction in cost',1134),(163,12,'Vey good',1135),(163,13,'By using Automation testing',1136),(163,14,'During development',1137),(163,15,'Yes',1138),(163,16,'80',1139),(163,17,'During testing',1140),(163,18,'No',1141),(163,19,'By working smarter',1142),(164,9,'Completed',1143),(164,10,'By reducing the time',1144),(164,11,'Reduction in cost',1145),(164,12,'Vey good',1146),(164,13,'By using Automation testing',1147),(164,14,'During development',1148),(164,15,'Yes',1149),(164,16,'81',1150),(164,17,'During testing',1151),(164,18,'No',1152),(164,19,'By working smarter',1153),(165,20,'Moderate',1154),(165,21,'80%',1155),(165,22,'Excellent',1156),(165,23,'At the time of development  & testing',1157),(165,24,'Worked on weekends',1158),(165,25,'By understanding the customer\'s view point',1159),(165,26,'Using automation testing',1160),(165,27,'60% & 7.2',1161),(165,28,'Yes',1162),(165,29,'By giving positive apprecition to the team members ',1163),(165,30,'At the time of development and testing',1164),(166,20,'High',1165),(166,21,'60%',1166),(166,22,'Excellent',1167),(166,23,'At the time of development  & testing',1168),(166,24,'Worked on weekends',1169),(166,25,'By understanding the customer\'s view point',1170),(166,26,'Using automation testing',1171),(166,27,'75% & 8.0',1172),(166,28,'Yes',1173),(166,29,'By giving positive apprecition to the team members ',1174),(166,30,'At the time of development and testing',1175),(167,20,'Moderate',1176),(167,21,'50%',1177),(167,22,'Excellent',1178),(167,23,'At the time of development  & testing',1179),(167,24,'Worked on weekends',1180),(167,25,'By understanding the customer\'s view point',1181),(167,26,'Using automation testing',1182),(167,27,'50% & 6.1',1183),(167,28,'Yes',1184),(167,29,'By giving positive apprecition to the team members ',1185),(167,30,'At the time of development and testing',1186),(168,20,'Moderate',1187),(168,21,'65%',1188),(168,22,'Excellent',1189),(168,23,'At the time of development  & testing',1190),(168,24,'Worked on weekends',1191),(168,25,'By understanding the customer\'s view point',1192),(168,26,'Using automation testing',1193),(168,27,'70% & 8.7',1194),(168,28,'Yes',1195),(168,29,'By giving positive apprecition to the team members ',1196),(168,30,'At the time of development and testing',1197),(169,31,'Automated compOff consolidation',1198),(169,32,'Worked on weekends',1199),(169,33,'reduction of cost',1200),(169,34,'manual process automated ',1201),(169,35,'Yes',1202),(169,36,'Excellent',1203),(169,37,'Very good',1204),(169,38,'Good',1205),(169,39,'Excellent',1206),(170,31,'Automated Rewards process',1207),(170,32,'Worked on weekends',1208),(170,33,'reduction of cost',1209),(170,34,'manual process automated ',1210),(170,35,'Yes',1211),(170,36,'Excellent',1212),(170,37,'Very good',1213),(170,38,'Good',1214),(170,39,'Excellent',1215),(171,31,'Voucher redeemption process automated ',1216),(171,32,'Worked on weekends',1217),(171,33,'reduction of cost',1218),(171,34,'manual process automated ',1219),(171,35,'Yes',1220),(171,36,'Excellent',1221),(171,37,'Very good',1222),(171,38,'Good',1223),(171,39,'Excellent',1224),(172,31,'Nomination process automated ',1225),(172,32,'Worked on weekends',1226),(172,33,'reduction of cost',1227),(172,34,'manual process automated ',1228),(172,35,'Yes',1229),(172,36,'Excellent',1230),(172,37,'Very good',1231),(172,38,'Good',1232),(172,39,'Excellent',1233);
/*!40000 ALTER TABLE `nominationremark` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-10 11:28:08
