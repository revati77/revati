package main.util;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;

@Component
public class FormatDate {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    public static java.sql.Date formateDate(String dateString) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date = formatter.parse(dateString);
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        return sqlDate;
    }

/*    public List<EmployeeReward> retrieveByDate(Integer empId, Date date1)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        c.add(Calendar.MONTH, -3);
        java.util.Date date2= c.getTime();
        return employeeRewardRepository.toGetByQuarterDate(empId,date1,date2);
    }*/



}
