package main.repository;

import main.bean.VoucherData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VoucherDataRepository extends JpaRepository<VoucherData, Long> {

    @Query(value = "select * from voucherdata e where e.QUARTER=?1 AND e.YEAR=?2 AND e.REWARD_TYPE=?3", nativeQuery = true)
    List<VoucherData> getQuarterlyWeekendInterviewData(String quarter, Integer year, String rewardType);

    @Query(value = "select * from voucherdata e where e.QUARTER=?1 AND e.YEAR=?2 AND e.REWARD_TYPE!=?3", nativeQuery = true)
    List<VoucherData> getQuarterlyNominationData(String quarter, Integer year, String rewardType);
}
