package main.repository;

import main.bean.EmployeeCompOff;
import main.bean.EmployeeReward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface EmployeeCompOffRepository extends JpaRepository<EmployeeCompOff, Long> {

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM EmployeeCompOff WHERE EMP_ID = ?1")
    void deleteByEmpId(Integer empId);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM EmployeeCompOff WHERE COMPOFF_ID = ?1")
    void deleteById(Long compOffId);


}
